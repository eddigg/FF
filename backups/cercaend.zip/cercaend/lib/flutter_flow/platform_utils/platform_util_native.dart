import 'dart:io';

bool get isMacOs => Platform.isMacOS;
String getUserAgent() => '';
