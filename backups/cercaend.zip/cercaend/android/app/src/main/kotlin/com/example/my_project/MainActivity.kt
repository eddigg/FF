package com.mycompany.cercaend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
